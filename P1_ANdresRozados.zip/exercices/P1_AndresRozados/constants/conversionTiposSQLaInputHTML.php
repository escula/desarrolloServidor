<?php
    const tiposDeSQLaHTMLinput=[
        "varchar"=>"text",
        "decimal"=>"number",
        "int"=>"number",
        "smallint"=>"number",
        "mediumtext"=>"text",
        "date"=>"date"
    ];
?>