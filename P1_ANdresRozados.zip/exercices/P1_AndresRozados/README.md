# Instalacion
cambiar el puerto en model

# Arquitectura usadas
- MVT
    Carpetas usadas para la arquitectura:
    - model
    - templates/generadorVistas 
    - templates/login 
    - templates/modalMensaje 
    - constants
    - controller/login

- MVC
    - model
    - templates/modificarTodo
    - constants
    - assets
    - controller/modificarTodo

Modificar todo es la pagina donde se ve la tabla y se realiza el crud (para esta se se a usado el MVC)

Para el login se ha usado MVT

Tened en cuenta que falta informe parte de front de insert y modificar (Estos se tendran para hoy)